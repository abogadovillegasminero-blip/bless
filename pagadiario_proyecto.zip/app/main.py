from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from services import registrar_pago

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def inicio():
    return open("templates/pagos.html").read()

@app.post("/pagar")
def pagar(cliente_id: int = Form(...), monto: float = Form(...)):
    registrar_pago(cliente_id, monto, "cobrador1")
    return {"ok": True}
