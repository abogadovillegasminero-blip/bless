from database import get_db
from datetime import date

def registrar_pago(cliente_id, monto, cobrador):
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT saldo FROM clientes WHERE id=?", (cliente_id,))
    saldo = cur.fetchone()[0]
    if monto > saldo:
        monto = saldo
    nuevo_saldo = saldo - monto
    cur.execute("UPDATE clientes SET saldo=?, estado=? WHERE id=?",
                (nuevo_saldo, "AL DIA" if nuevo_saldo > 0 else "PAGADO", cliente_id))
    cur.execute("INSERT INTO pagos (cliente_id, fecha, monto, cobrador) VALUES (?,?,?,?)",
                (cliente_id, date.today().isoformat(), monto, cobrador))
    db.commit()
