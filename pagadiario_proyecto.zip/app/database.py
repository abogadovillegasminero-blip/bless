import sqlite3
def get_db():
    return sqlite3.connect("pagadiario.db", check_same_thread=False)
