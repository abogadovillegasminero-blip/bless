from app.models.cliente import Cliente
from app.models.prestamo import Prestamo
from app.models.cuota import Cuota
