from fastapi import FastAPI
from fastapi.responses import RedirectResponse

from app.auth import router as auth_router
from app.clientes import router as clientes_router
from app.pagos import router as pagos_router
from app.reportes import router as reportes_router

app = FastAPI()

# =====================
# RUTA RAÍZ
# =====================
@app.get("/")
def root():
    return RedirectResponse("/login-ui")

# =====================
# ROUTERS
# =====================
app.include_router(auth_router)
app.include_router(clientes_router)
app.include_router(pagos_router)
app.include_router(reportes_router)
