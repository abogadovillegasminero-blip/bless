@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(user=Depends(get_current_user)):
    return """
    <h2>Dashboard Bless</h2>
    <a href="/clientes">Clientes</a><br><br>
    <a href="/pagos">Pagos</a><br><br>
    <a href="/reportes">Reportes</a><br><br>
    <a href="/saldos">Saldos</a><br><br>
    <a href="/logout">Salir</a>
    """
