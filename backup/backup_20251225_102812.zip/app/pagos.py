from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from app.auth_utils import get_current_user
import pandas as pd
import os

router = APIRouter()

@router.get("/pagos", response_class=HTMLResponse)
def pagos(user=Depends(get_current_user)):
    return """
    <h2>Registrar Pago</h2>

    <form method="post">
        Cliente:<br>
        <input type="text" name="cliente" required><br><br>

        Valor:<br>
        <input type="number" name="valor" required><br><br>

        <button type="submit">Guardar</button>
    </form>

    <br>
    <a href="/dashboard">Volver</a>
    """

@router.post("/pagos")
def guardar_pago(
    cliente: str = Form(...),
    valor: float = Form(...),
    user=Depends(get_current_user)
):
    ruta = "data/pagos.xlsx"

    nuevo = pd.DataFrame([{
        "cliente": cliente,
        "valor": valor
    }])

    if os.path.exists(ruta):
        df = pd.read_excel(ruta)
        df = pd.concat([df, nuevo], ignore_index=True)
    else:
        df = nuevo

    os.makedirs("data", exist_ok=True)
    df.to_excel(ruta, index=False)

    return RedirectResponse("/pagos", status_code=303)
