from .prestamo import Prestamo
from .cuota import Cuota
