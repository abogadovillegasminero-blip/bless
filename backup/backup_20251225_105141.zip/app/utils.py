from fastapi import Request
from fastapi.responses import RedirectResponse

def get_current_user(request: Request):
    # Login simple sin sesiones aún
    return True
